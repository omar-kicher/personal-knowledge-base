// This file would typically interact with a database
// For this demo, we're using in-memory data

export type Page = {
  id: string
  title: string
  content: string
  excerpt: string
  lastEdited: string
  tags: string[]
  isFeatured?: boolean
}

// In a real app, this would be stored in a database
let pages: Page[] = [
  {
    id: "1",
    title: "Project Ideas",
    content: "# Project Ideas\n\nHere's a collection of project ideas...",
    excerpt: "Collection of project ideas for future development",
    lastEdited: "2 hours ago",
    tags: ["projects", "ideas"],
  },
  {
    id: "2",
    title: "Meeting Notes",
    content: "# Meeting Notes\n\nNotes from the weekly team meeting...",
    excerpt: "Notes from the weekly team meeting",
    lastEdited: "Yesterday",
    tags: ["meetings", "work"],
  },
  {
    id: "3",
    title: "Reading List",
    content: "# Reading List\n\nBooks and articles I want to read...",
    excerpt: "Books and articles I want to read",
    lastEdited: "3 days ago",
    tags: ["reading", "personal"],
    isFeatured: true,
  },
  {
    id: "4",
    title: "Personal Goals",
    content: "# Personal Goals\n\nMy goals and aspirations for the year...",
    excerpt: "My goals and aspirations for the year",
    lastEdited: "1 week ago",
    tags: ["personal", "goals"],
    isFeatured: true,
  },
  {
    id: "5",
    title: "Tech Stack",
    content: "# Tech Stack\n\nOverview of my preferred technologies and tools...",
    excerpt: "Overview of my preferred technologies and tools",
    lastEdited: "2 weeks ago",
    tags: ["tech", "reference"],
  },
]

export function getAllPages(): Page[] {
  return pages
}

export function getPageById(id: string): Page | undefined {
  return pages.find((page) => page.id === id)
}

export function getRecentPages(limit = 3): Page[] {
  return [...pages]
    .sort((a, b) => {
      // Simple sorting by "lastEdited" string for demo purposes
      // In a real app, we would use actual dates
      return a.lastEdited.localeCompare(b.lastEdited)
    })
    .slice(0, limit)
}

export function getFeaturedPages(): Page[] {
  return pages.filter((page) => page.isFeatured)
}

export function createPage(page: Omit<Page, "id" | "lastEdited">): Page {
  const newPage: Page = {
    ...page,
    id: (pages.length + 1).toString(),
    lastEdited: "Just now",
  }

  pages.push(newPage)
  return newPage
}

export function updatePage(id: string, updates: Partial<Omit<Page, "id" | "lastEdited">>): Page | null {
  const pageIndex = pages.findIndex((page) => page.id === id)

  if (pageIndex === -1) {
    return null
  }

  pages[pageIndex] = {
    ...pages[pageIndex],
    ...updates,
    lastEdited: "Just now",
  }

  return pages[pageIndex]
}

export function deletePage(id: string): boolean {
  const initialLength = pages.length
  pages = pages.filter((page) => page.id !== id)
  return pages.length < initialLength
}

