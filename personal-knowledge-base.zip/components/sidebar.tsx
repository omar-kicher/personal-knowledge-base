"use client"

import type React from "react"

import Link from "next/link"
import { useState } from "react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Home, Search, FolderOpen, Star, Tag, Settings, Menu, X, PlusCircle, BookOpen } from "lucide-react"
import { useMobile } from "@/hooks/use-mobile"

export function Sidebar() {
  const isMobile = useMobile()
  const [isOpen, setIsOpen] = useState(!isMobile)

  const toggleSidebar = () => {
    setIsOpen(!isOpen)
  }

  return (
    <>
      {isMobile && (
        <Button variant="ghost" size="icon" className="fixed top-4 left-4 z-50" onClick={toggleSidebar}>
          {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>
      )}

      <div
        className={cn(
          "bg-muted/40 border-r w-64 p-4 flex flex-col h-screen transition-all duration-300 ease-in-out",
          isMobile && "fixed z-40",
          isMobile && !isOpen && "-translate-x-full",
        )}
      >
        <div className="flex items-center gap-2 mb-6 px-2">
          <BookOpen className="h-6 w-6 text-primary" />
          <h1 className="font-bold text-xl">KnowledgeBase</h1>
        </div>

        <div className="space-y-1 mb-6">
          <Link href="/pages/new">
            <Button variant="outline" className="w-full justify-start">
              <PlusCircle className="mr-2 h-4 w-4" />
              New Page
            </Button>
          </Link>
        </div>

        <nav className="space-y-1 mb-6">
          <NavItem href="/" icon={<Home className="h-4 w-4 mr-2" />}>
            Home
          </NavItem>
          <NavItem href="/search" icon={<Search className="h-4 w-4 mr-2" />}>
            Search
          </NavItem>
          <NavItem href="/all-pages" icon={<FolderOpen className="h-4 w-4 mr-2" />}>
            All Pages
          </NavItem>
          <NavItem href="/favorites" icon={<Star className="h-4 w-4 mr-2" />}>
            Favorites
          </NavItem>
          <NavItem href="/tags" icon={<Tag className="h-4 w-4 mr-2" />}>
            Tags
          </NavItem>
        </nav>

        <div className="space-y-1 mb-4">
          <h2 className="text-sm font-semibold text-muted-foreground px-3 py-2">Workspaces</h2>
          <NavItem href="/workspace/personal" icon={<div className="w-2 h-2 rounded-full bg-blue-500 mr-2" />}>
            Personal
          </NavItem>
          <NavItem href="/workspace/work" icon={<div className="w-2 h-2 rounded-full bg-green-500 mr-2" />}>
            Work
          </NavItem>
          <NavItem href="/workspace/projects" icon={<div className="w-2 h-2 rounded-full bg-purple-500 mr-2" />}>
            Projects
          </NavItem>
        </div>

        <div className="mt-auto">
          <Link href="/ai-assistant">
            <Button variant="secondary" className="w-full mb-4">
              AI Assistant
            </Button>
          </Link>
          <NavItem href="/settings" icon={<Settings className="h-4 w-4 mr-2" />}>
            Settings
          </NavItem>
        </div>
      </div>
    </>
  )
}

function NavItem({ href, icon, children }: { href: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <Link href={href}>
      <Button variant="ghost" className="w-full justify-start">
        {icon}
        {children}
      </Button>
    </Link>
  )
}

