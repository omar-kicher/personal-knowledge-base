import Link from "next/link"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Clock } from "lucide-react"

// In a real app, this would come from a database
const recentPages = [
  {
    id: "1",
    title: "Project Ideas",
    excerpt: "Collection of project ideas for future development",
    lastEdited: "2 hours ago",
    tags: ["projects", "ideas"],
  },
  {
    id: "2",
    title: "Meeting Notes",
    excerpt: "Notes from the weekly team meeting",
    lastEdited: "Yesterday",
    tags: ["meetings", "work"],
  },
  {
    id: "3",
    title: "Reading List",
    excerpt: "Books and articles I want to read",
    lastEdited: "3 days ago",
    tags: ["reading", "personal"],
  },
]

export function RecentPages() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      {recentPages.map((page) => (
        <Link href={`/pages/${page.id}`} key={page.id}>
          <Card className="h-full hover:bg-muted/50 transition-colors">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">{page.title}</CardTitle>
              <CardDescription className="line-clamp-2">{page.excerpt}</CardDescription>
            </CardHeader>
            <CardContent className="pb-2">
              <div className="flex flex-wrap gap-1">
                {page.tags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="text-xs">
                    {tag}
                  </Badge>
                ))}
              </div>
            </CardContent>
            <CardFooter className="text-xs text-muted-foreground">
              <div className="flex items-center">
                <Clock className="mr-1 h-3 w-3" />
                <span>Edited {page.lastEdited}</span>
              </div>
            </CardFooter>
          </Card>
        </Link>
      ))}
    </div>
  )
}

