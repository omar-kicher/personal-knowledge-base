import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star } from "lucide-react"

// In a real app, this would come from a database
const featuredPages = [
  {
    id: "4",
    title: "Personal Goals",
    excerpt: "My goals and aspirations for the year",
    tags: ["personal", "goals"],
  },
  {
    id: "5",
    title: "Tech Stack",
    excerpt: "Overview of my preferred technologies and tools",
    tags: ["tech", "reference"],
  },
]

export function FeaturedPages() {
  return (
    <div className="grid gap-4 md:grid-cols-2">
      {featuredPages.map((page) => (
        <Link href={`/pages/${page.id}`} key={page.id}>
          <Card className="h-full hover:bg-muted/50 transition-colors border-primary/20">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{page.title}</CardTitle>
                <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
              </div>
              <CardDescription className="line-clamp-2">{page.excerpt}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-1">
                {page.tags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="text-xs">
                    {tag}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        </Link>
      ))}
    </div>
  )
}

