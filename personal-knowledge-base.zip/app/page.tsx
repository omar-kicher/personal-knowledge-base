import Link from "next/link"
import { Button } from "@/components/ui/button"
import { PlusCircle, BookOpen } from "lucide-react"
import { Sidebar } from "@/components/sidebar"
import { SearchBar } from "@/components/search-bar"
import { RecentPages } from "@/components/recent-pages"
import { FeaturedPages } from "@/components/featured-pages"

export default function HomePage() {
  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <div className="container max-w-6xl py-6">
          <div className="flex items-center justify-between mb-8">
            <h1 className="text-3xl font-bold">My Knowledge Base</h1>
            <div className="flex items-center gap-4">
              <SearchBar />
              <Link href="/pages/new">
                <Button>
                  <PlusCircle className="mr-2 h-4 w-4" />
                  New Page
                </Button>
              </Link>
            </div>
          </div>

          <div className="grid gap-8">
            <section>
              <h2 className="text-2xl font-semibold mb-4">Recent Pages</h2>
              <RecentPages />
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">Featured Pages</h2>
              <FeaturedPages />
            </section>

            <section className="bg-muted p-6 rounded-lg">
              <div className="flex items-start gap-4">
                <div className="bg-primary/10 p-3 rounded-full">
                  <BookOpen className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="text-xl font-medium mb-2">Get Started with Your Knowledge Base</h3>
                  <p className="text-muted-foreground mb-4">
                    Organize your personal information, notes, and ideas in one place. Create pages, add content, and
                    use the AI assistant to help you.
                  </p>
                  <div className="flex gap-3">
                    <Link href="/pages/new">
                      <Button variant="default" size="sm">
                        Create Your First Page
                      </Button>
                    </Link>
                    <Link href="/ai-assistant">
                      <Button variant="outline" size="sm">
                        Try AI Assistant
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            </section>
          </div>
        </div>
      </main>
    </div>
  )
}

