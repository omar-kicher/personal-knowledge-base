"use client"

import type React from "react"
import { useChat } from "ai/react"
import { Sidebar } from "@/components/sidebar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar } from "@/components/ui/avatar"
import { ArrowLeft, Send, Bot, User } from "lucide-react"
import Link from "next/link"

export default function AIAssistant() {
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat({
    api: "/api/chat",
  })

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <main className="flex-1 flex flex-col overflow-hidden">
        <div className="border-b p-4 flex items-center gap-2">
          <Link href="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-xl font-semibold">AI Assistant</h1>
        </div>

        <div className="flex-1 overflow-auto p-4">
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-8">
              <div className="bg-primary/10 p-3 rounded-full mb-4">
                <Bot className="h-6 w-6 text-primary" />
              </div>
              <h2 className="text-2xl font-semibold mb-2">AI Knowledge Assistant</h2>
              <p className="text-muted-foreground max-w-md mb-8">
                Ask me anything about your knowledge base, or get help with writing, summarizing, or organizing your
                content.
              </p>
              <div className="grid gap-2 max-w-md w-full">
                <SuggestionButton>Summarize my "Project Ideas" page</SuggestionButton>
                <SuggestionButton>Help me brainstorm content for a new page about productivity</SuggestionButton>
                <SuggestionButton>Create a template for meeting notes</SuggestionButton>
              </div>
            </div>
          ) : (
            <div className="space-y-4 max-w-3xl mx-auto">
              {messages.map((message) => (
                <div key={message.id} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
                  <div className={`flex gap-3 max-w-[80%] ${message.role === "user" ? "flex-row-reverse" : ""}`}>
                    <Avatar className={message.role === "user" ? "bg-primary" : "bg-muted"}>
                      {message.role === "user" ? (
                        <User className="h-5 w-5 text-primary-foreground" />
                      ) : (
                        <Bot className="h-5 w-5" />
                      )}
                    </Avatar>
                    <div
                      className={`rounded-lg p-4 ${
                        message.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted"
                      }`}
                    >
                      {message.content}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="border-t p-4">
          <form onSubmit={handleSubmit} className="flex gap-2 max-w-3xl mx-auto">
            <Input value={input} onChange={handleInputChange} placeholder="Ask anything..." className="flex-1" />
            <Button type="submit" disabled={isLoading || !input.trim()}>
              <Send className="h-4 w-4" />
            </Button>
          </form>
        </div>
      </main>
    </div>
  )
}

function SuggestionButton({ children }: { children: React.ReactNode }) {
  return (
    <Button variant="outline" className="justify-start h-auto py-3 px-4 text-left">
      {children}
    </Button>
  )
}

