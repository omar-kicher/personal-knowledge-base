import Link from "next/link"
import { notFound } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Sidebar } from "@/components/sidebar"
import { ArrowLeft, Edit, Star, Clock, Tag } from "lucide-react"

// In a real app, this would come from a database
const pages = [
  {
    id: "1",
    title: "Project Ideas",
    content: `
# Project Ideas

Here's a collection of project ideas I'm considering for future development:

## Web Development
- Personal portfolio website with interactive elements
- Recipe sharing platform with social features
- Productivity dashboard with integrations

## Mobile Apps
- Habit tracker with gamification
- Language learning flashcard app
- Local event discovery app

## Other Ideas
- Smart home dashboard
- Personal finance tracker
- Book recommendation system
    `,
    lastEdited: "2 hours ago",
    tags: ["projects", "ideas"],
  },
  {
    id: "2",
    title: "Meeting Notes",
    content: `
# Weekly Team Meeting Notes

Date: March 8, 2025
Attendees: John, Sarah, Michael, Emma

## Agenda
1. Project status updates
2. Upcoming deadlines
3. New feature discussion
4. Open issues

## Action Items
- [ ] Sarah to finalize the design by Wednesday
- [ ] Michael to review the code by Friday
- [ ] Emma to prepare the presentation for next week
- [ ] John to coordinate with the client

## Notes
The team discussed the progress on the current sprint and identified some blockers that need to be addressed. We agreed to prioritize the user authentication feature for the next release.
    `,
    lastEdited: "Yesterday",
    tags: ["meetings", "work"],
  },
  {
    id: "3",
    title: "Reading List",
    content: `
# Reading List

## Books
- "Atomic Habits" by James Clear
- "The Psychology of Money" by Morgan Housel
- "Project Hail Mary" by Andy Weir
- "Designing Data-Intensive Applications" by Martin Kleppmann

## Articles
- [The Effective Engineer](https://www.effectiveengineer.com/blog)
- [How to Take Smart Notes](https://fortelabs.co/blog/how-to-take-smart-notes/)
- [Mental Models for Designers](https://uxdesign.cc/mental-models-for-designers-7c84cc6b8a9e)

## Technical Papers
- Distributed Systems: Principles and Paradigms
- Attention Is All You Need (Transformer paper)
    `,
    lastEdited: "3 days ago",
    tags: ["reading", "personal"],
  },
  {
    id: "4",
    title: "Personal Goals",
    content: `
# Personal Goals for 2025

## Career
- Complete advanced certification in web development
- Contribute to 3 open-source projects
- Improve public speaking skills

## Health & Fitness
- Exercise at least 4 times per week
- Maintain a consistent sleep schedule
- Practice meditation daily

## Learning
- Learn a new programming language
- Read at least 20 books
- Take an online course on machine learning

## Personal Projects
- Launch personal website
- Create a side project that generates passive income
- Improve photography skills
    `,
    lastEdited: "1 week ago",
    tags: ["personal", "goals"],
  },
  {
    id: "5",
    title: "Tech Stack",
    content: `
# My Tech Stack

## Frontend
- React.js
- Next.js
- Tailwind CSS
- TypeScript

## Backend
- Node.js
- Express
- PostgreSQL
- Redis

## DevOps
- Docker
- GitHub Actions
- Vercel
- AWS (S3, Lambda)

## Tools
- VS Code
- Figma
- Postman
- Git
    `,
    lastEdited: "2 weeks ago",
    tags: ["tech", "reference"],
  },
]

export default function PageView({ params }: { params: { id: string } }) {
  const page = pages.find((p) => p.id === params.id)

  if (!page) {
    notFound()
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <div className="container max-w-4xl py-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Link href="/">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-4 w-4" />
                </Button>
              </Link>
              <h1 className="text-2xl font-bold">{page.title}</h1>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon">
                <Star className="h-4 w-4" />
              </Button>
              <Link href={`/pages/${page.id}/edit`}>
                <Button>
                  <Edit className="mr-2 h-4 w-4" />
                  Edit
                </Button>
              </Link>
            </div>
          </div>

          <div className="flex items-center gap-4 text-sm text-muted-foreground mb-6">
            <div className="flex items-center">
              <Clock className="mr-1 h-4 w-4" />
              <span>Edited {page.lastEdited}</span>
            </div>
            <div className="flex items-center">
              <Tag className="mr-1 h-4 w-4" />
              <div className="flex gap-1">
                {page.tags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="text-xs">
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>
          </div>

          <div className="prose prose-sm md:prose-base dark:prose-invert max-w-none">
            {page.content.split("\n").map((line, index) => {
              if (line.startsWith("# ")) {
                return (
                  <h1 key={index} className="text-3xl font-bold mt-6 mb-4">
                    {line.substring(2)}
                  </h1>
                )
              } else if (line.startsWith("## ")) {
                return (
                  <h2 key={index} className="text-2xl font-semibold mt-5 mb-3">
                    {line.substring(3)}
                  </h2>
                )
              } else if (line.startsWith("- ")) {
                return (
                  <li key={index} className="ml-6">
                    {line.substring(2)}
                  </li>
                )
              } else if (line.startsWith("- [ ] ")) {
                return (
                  <div key={index} className="flex items-start gap-2 ml-6 my-1">
                    <input type="checkbox" className="mt-1" />
                    <span>{line.substring(6)}</span>
                  </div>
                )
              } else if (line.trim() === "") {
                return <div key={index} className="h-4"></div>
              } else {
                return (
                  <p key={index} className="my-2">
                    {line}
                  </p>
                )
              }
            })}
          </div>
        </div>
      </main>
    </div>
  )
}

