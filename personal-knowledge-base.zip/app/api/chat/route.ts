import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
import { NextResponse } from "next/server"

// In a real app, we would fetch this data from a database
const knowledgeBase = [
  {
    id: "1",
    title: "Project Ideas",
    content: "Collection of project ideas for future development...",
  },
  {
    id: "2",
    title: "Meeting Notes",
    content: "Notes from the weekly team meeting...",
  },
  {
    id: "3",
    title: "Reading List",
    content: "Books and articles I want to read...",
  },
]

export async function POST(req: Request) {
  try {
    const { messages } = await req.json()

    // Get the last user message
    const lastUserMessage = messages.filter((m: any) => m.role === "user").pop()

    // Create a system prompt that includes knowledge base context
    const systemPrompt = `You are an AI assistant for a personal knowledge base application.
    
    The user's knowledge base contains the following pages:
    ${knowledgeBase.map((page) => `- ${page.title}: ${page.content}`).join("\n")}
    
    Help the user with their questions about their knowledge base, writing content, organizing information, or any other related tasks.
    Be concise, helpful, and friendly.`

    const { text } = await generateText({
      model: openai("gpt-4o"),
      system: systemPrompt,
      prompt: lastUserMessage.content,
    })

    return NextResponse.json({ role: "assistant", content: text })
  } catch (error) {
    console.error("Error in chat route:", error)
    return NextResponse.json({ error: "There was an error processing your request" }, { status: 500 })
  }
}

